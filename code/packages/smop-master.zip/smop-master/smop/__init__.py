# SMOP compiler -- Simple Matlab/Octave to Python compiler
# Copyright 2011-2014 Victor Leikehman

import version
import parse,resolve,backend,main
from version import __version__
