
# THIS FILE IS GENERATED FROM SLYCOT SETUP.PY
short_version = '0.2.0'
version = '0.2.0'
full_version = '0.2.0'
git_revision = 'c0e46876f8f2a1b01077d836f2f953e76075d71d'
release = True

if not release:
    version = full_version
